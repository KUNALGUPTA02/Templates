var mn = document.getElementsByClassName("main");
var i;

for (i = 0; i < mn.length; i++) {
    mn[i].onclick = function () {
        this.classList.toggle("active");
        this.nextElementSibling.classList.toggle("show");
    }
}